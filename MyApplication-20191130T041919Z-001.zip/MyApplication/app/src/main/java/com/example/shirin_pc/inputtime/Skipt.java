package com.example.shirin_pc.inputtime;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Skipt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_skipt);
    }
}
